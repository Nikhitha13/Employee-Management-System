import customtkinter as ctk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import sys

# --- Appearance ---
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# --- Get user email from CLI ---
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# === Feature Commands ===
def open_personal_info():
    root.destroy()
    subprocess.Popen(["python", "personal_info.py", user_email])

def open_clock_in_out():
    root.destroy()
    subprocess.Popen(["python", "clock_in_out.py", user_email])

def open_time_sheet():
    root.destroy()
    subprocess.Popen(["python", "time_sheet.py", user_email])

def open_change_password():
    root.destroy()
    subprocess.Popen(["python", "change_password.py", user_email])

def go_back():
    root.destroy()
    subprocess.Popen(["python", "login.py"])

def sign_out():
    go_back()

# === Main Window ===
root = ctk.CTk()
root.title("Employee Dashboard")
root.geometry("900x600")
root.resizable(False, False)
root.configure(fg_color="white")
primary_color = "#92E3B4"

# === Sidebar ===
sidebar = ctk.CTkFrame(root, width=250, height=600, fg_color=primary_color, corner_radius=0)
sidebar.place(x=0, y=0)

# === Sidebar Header ===
try:
    icon_img = Image.open("images/dashboard.png").resize((26, 26), Image.LANCZOS)
    dashboard_icon = ctk.CTkImage(light_image=icon_img, size=(26, 26))
except:
    dashboard_icon = None

ctk.CTkLabel(sidebar, text=" Employee Dashboard", image=dashboard_icon,
             compound="left", font=("Arial", 16, "bold"), text_color="black", anchor="w").place(x=10, y=15)

ctk.CTkFrame(sidebar, height=2, width=230, fg_color="white").place(x=10, y=55)

# === Sidebar Labels ===
def add_sidebar_label(y, text, icon_path):
    try:
        img = Image.open(icon_path).resize((24, 24))
        icon = ctk.CTkImage(light_image=img, size=(24, 24))
    except:
        icon = None

    ctk.CTkLabel(sidebar, text=" " + text, image=icon, compound="left", font=("Arial", 14),
                 text_color="black", fg_color=primary_color, anchor="w").place(x=20, y=y)

# === Sidebar Buttons (Clickable) ===
def add_sidebar_button(y, text, icon_path, command=None):
    try:
        img = Image.open(icon_path).resize((24, 24))
        icon = ctk.CTkImage(light_image=img, size=(24, 24))
    except:
        icon = None

    btn = ctk.CTkButton(sidebar, text=" " + text, image=icon, compound="left",
                        font=("Arial", 14), text_color="black",
                        fg_color=primary_color, hover_color="#7ED9A2",
                        corner_radius=10, width=200, anchor="w")
    btn.place(x=20, y=y)
    if command:
        btn.configure(command=command)

# Use buttons instead of labels
add_sidebar_button(100, "Home", "images/home_icon.png")
add_sidebar_button(150, "Password change", "images/performance_icon.png", open_change_password)
add_sidebar_button(200, "Time log", "images/calendar_icon.png", open_time_sheet)


# === Sidebar Bottom Buttons ===
def add_bottom_button(text, icon_path, y, command=None):
    try:
        img = Image.open(icon_path).resize((24, 24))
        icon = ctk.CTkImage(light_image=img, size=(24, 24))
    except:
        icon = None

    btn = ctk.CTkButton(sidebar, text=text, image=icon, compound="left",
                        font=("Arial", 14), text_color="black",
                        fg_color=primary_color, hover_color=primary_color,
                        corner_radius=10, width=200, anchor="w")
    btn.place(x=20, y=y)
    if command:
        btn.configure(command=command)

add_bottom_button("Team", "images/team_icon.png", 460)
add_bottom_button("Sign Out", "images/signout_icon.png", 510, sign_out)

# === Content Frame ===
content_frame = ctk.CTkFrame(root, width=650, height=600, fg_color="white", corner_radius=0)
content_frame.place(x=250, y=0)

# === Load & Place Icons ===
def load_feature_icon(path):
    try:
        icon = Image.open(path).resize((60, 60))
        return ctk.CTkImage(light_image=icon, size=(60, 60))
    except:
        return None

def create_feature_button(text, icon, command, y_pos):
    ctk.CTkLabel(content_frame, image=icon, text="", bg_color="white").place(x=295, y=y_pos)
    ctk.CTkButton(content_frame, text=text, command=command, width=260, height=50,
                  fg_color=primary_color, text_color="black", font=("Arial", 14),
                  corner_radius=12).place(x=195, y=y_pos + 70)

# === Feature Buttons & Icons ===
profile_icon = load_feature_icon("images/profile_icon.png")
clock_icon = load_feature_icon("images/clock_icon.png")
sheet_icon = load_feature_icon("images/timesheet_icon.png")
password_icon = load_feature_icon("images/key.png")  # Ensure this icon exists

# === Place Buttons (Spaced for No Overlap) ===
create_feature_button("View/Update Personal Information", profile_icon, open_personal_info, 30)
create_feature_button("Clock-In / Clock-Out", clock_icon, open_clock_in_out, 150)
create_feature_button("Time Sheet", sheet_icon, open_time_sheet, 270)
create_feature_button("Change Password", password_icon, open_change_password, 390)

# === Back Button ===
ctk.CTkButton(root, text="← Back", command=go_back, width=80,
              fg_color="white", text_color="black", hover_color="#ddd",
              font=("Arial", 14)).place(x=870, y=10, anchor="ne")

# === Launch ===
root.mainloop()
