import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
import subprocess
from PIL import Image, ImageTk
from database import get_db_connection

# === Theme Setup ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Function to get user info and check status ===
def get_user_by_email(email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, role, password, status FROM User WHERE email=%s", (email,))
    user = cursor.fetchone()
    conn.close()
    return user  # Tuple: (user_id, role, password, status) or None

# === Toggle password visibility ===
def toggle_password():
    if show_pass_var.get():
        password_entry.configure(show="")
    else:
        password_entry.configure(show="*")

# === Login Function ===
def login():
    email = email_entry.get().strip()
    password = password_entry.get().strip()

    if not email or not password:
        messagebox.showerror("❌ Error", "Please enter both email and password!")
        return

    user = get_user_by_email(email)
    if user:
        user_id, role, db_password, status = user

        if status != "active":
            messagebox.showerror("❌ Access Denied", "This user account is inactive.")
            return

        if password == db_password:  # 🔐 In production, hash the passwords!
            if role == "admin":
                subprocess.Popen(["python", "admin_dashboard.py", email])
            else:
                subprocess.Popen(["python", "employee_dashboard.py", email])
            root.destroy()
        else:
            messagebox.showerror("❌ Error", "Incorrect password. Please try again.")
    else:
        messagebox.showerror("❌ Error", "User not found. Please check your email.")

# === UI Setup ===
root = ctk.CTk()
root.title("Login - WMS")
root.geometry("900x600")
root.resizable(False, False)

# === Left Login Form ===
left_frame = ctk.CTkFrame(root, width=450, height=600, fg_color="white")
left_frame.place(x=0, y=0)

title_label = ctk.CTkLabel(left_frame, text="Hi, Welcome Back!", font=("Segoe UI", 32, "bold"), text_color="black")
title_label.place(x=49, y=79)

email_label = ctk.CTkLabel(left_frame, text="Email Address", font=("Roboto", 14), text_color="black")
email_label.place(x=49, y=140)
email_entry = ctk.CTkEntry(left_frame, width=300, height=55, placeholder_text="Enter your email")
email_entry.place(x=51, y=180)

password_label = ctk.CTkLabel(left_frame, text="Password", font=("Roboto", 14), text_color="black")
password_label.place(x=49, y=246)
password_entry = ctk.CTkEntry(left_frame, width=300, height=55, show="*", placeholder_text="8+ characters required")
password_entry.place(x=51, y=291)

# Password toggle
show_pass_var = tk.BooleanVar()
show_pass_switch = ctk.CTkSwitch(
    master=left_frame,
    text="Show Password",
    font=("Segoe UI", 13, "bold"),
    command=toggle_password,
    variable=show_pass_var,
    onvalue=True,
    offvalue=False,
    progress_color="green"
)
show_pass_switch.place(x=59, y=375)

# Login button
login_button = ctk.CTkButton(
    left_frame,
    text="🔓 LOGIN",
    command=login,
    fg_color="#51AD77",
    text_color="white",
    font=("Arial", 14, "bold"),
    width=340,
    height=50
)
login_button.place(x=51, y=437)

# === Right Image Frame ===
right_frame = ctk.CTkFrame(root, width=450, height=600, fg_color="#92E3B4")
right_frame.place(x=450, y=0)

# Image display
try:
    image = Image.open("images/loginimage1.png").resize((400, 400), Image.LANCZOS)
    photo = ImageTk.PhotoImage(image)
    image_label = tk.Label(right_frame, image=photo, bg="#92E3B4")
    image_label.image = photo
    image_label.place(x=25, y=150)
except Exception as e:
    print(f"Image load error: {e}")

# === Run App ===
root.mainloop()
