import customtkinter as ctk
from PIL import Image, ImageTk
import subprocess

# === Appearance Settings ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Main Window ===
root = ctk.CTk()
root.title("Viji Consultancy - Employee Management System")
root.geometry("750x500")
root.resizable(False, False)
bg_color = "#92E3B4"
root.configure(fg_color=bg_color)

# === Background Image (Smaller and Higher) ===
try:
    bg_image = Image.open("images/home2.png").resize((700, 500))
    bg_image = ImageTk.PhotoImage(bg_image)
    bg_label = ctk.CTkLabel(root, image=bg_image, text="")
    bg_label.place(relx=0.5, rely=0.47, anchor="center")  # moved slightly higher
except:
    print("⚠️ Background image not found at images/company-bro.png")

# === Titles Moved Closer to Image ===
ctk.CTkLabel(root, text="Viji Consultancy", font=("Arial", 18, "bold"),
             text_color="#204E4A").place(x=300, y=50)

ctk.CTkLabel(root, text="Employee Management System", font=("Arial", 22, "bold"),
             text_color="#204E4A").place(x=220, y=20)

# === Login Button (Centered Under Image) ===
def open_login():
    subprocess.Popen(["python", "login.py"])
    root.destroy()

ctk.CTkButton(root, text="Login", command=open_login, width=180, height=38,
              fg_color="#204E4A", hover_color="#1b3f3b", text_color="white",
              font=("Arial", 14, "bold")).place(relx=0.5, rely=0.84, anchor="center")

# === Footer ===
ctk.CTkLabel(root, text="© 2024 Viji Consultancy", font=("Arial", 10),
             text_color="#204E4A").place(relx=0.5, rely=1, y=-15, anchor="center")

# === Run App ===
root.mainloop()
