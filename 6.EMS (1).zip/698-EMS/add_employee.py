import customtkinter as ctk
from tkinter import messagebox
import re
import subprocess
import sys
from database import get_db_connection

# Get admin email from args
admin_email = sys.argv[1] if len(sys.argv) > 1 else "admin@gmail.com"

# === Theme Setup ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Main Window ===
root = ctk.CTk()
root.title("Add Employee")
root.geometry("600x600")
root.resizable(False, False)
root.configure(fg_color="#92E3B4")

# === Header Frame ===
header = ctk.CTkFrame(root, height=60, fg_color="#92E3B4")
header.pack(fill="x")

ctk.CTkLabel(header, text="➕ Add Employee", font=("Arial", 20, "bold"), text_color="black").place(x=20, y=15)

# === Form Frame ===
form_frame = ctk.CTkFrame(root, fg_color="white")
form_frame.pack(pady=20, padx=30, fill="both", expand=True)

# === Input Fields ===
def create_label_entry(text, row):
    label = ctk.CTkLabel(form_frame, text=text, font=("Arial", 13), text_color="black")
    label.grid(row=row, column=0, sticky="w", padx=20, pady=8)
    entry = ctk.CTkEntry(form_frame, width=300)
    entry.grid(row=row, column=1, padx=10)
    return entry

fname_entry = create_label_entry("First Name", 0)
lname_entry = create_label_entry("Last Name", 1)
email_entry = create_label_entry("Email", 2)
password_entry = create_label_entry("Password", 3)
phone_entry = create_label_entry("Phone", 4)
department_entry = create_label_entry("Department", 5)
position_entry = create_label_entry("Position", 6)
experience_entry = create_label_entry("Experience (Years)", 7)
salary_entry = create_label_entry("Salary", 8)

# === Add Employee Logic ===
def add_employee():
    fname = fname_entry.get().strip()
    lname = lname_entry.get().strip()
    email = email_entry.get().strip()
    password = password_entry.get().strip()
    phone = phone_entry.get().strip()
    dept = department_entry.get().strip()
    pos = position_entry.get().strip()
    exp = experience_entry.get().strip()
    salary = salary_entry.get().strip()

    # === Basic Validations ===
    if not all([fname, lname, email, password, phone, dept, pos, exp, salary]):
        messagebox.showerror("Error", "Please fill all fields.")
        return

    if not re.match(r"[^@]+@gmail\.com$", email):
        messagebox.showerror("Error", "Email must be a valid @gmail.com address.")
        return

    if len(password) < 8:
        messagebox.showerror("Error", "Password must be at least 8 characters.")
        return

    try:
        exp = int(exp)
        salary = float(salary)
    except ValueError:
        messagebox.showerror("Error", "Experience must be an integer and salary must be a number.")
        return

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert into User
        cursor.execute("""
            INSERT INTO User (first_name, last_name, email, password, phone, role)
            VALUES (%s, %s, %s, %s, %s, 'employee')
        """, (fname, lname, email, password, phone))

        user_id = cursor.lastrowid

        # Insert into Employee
        cursor.execute("""
            INSERT INTO Employee (user_id, position, department, experience, address, job_info, skills, salary)
            VALUES (%s, %s, %s, %s, '', '', '', %s)
        """, (user_id, pos, dept, exp, salary))

        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Employee added successfully!")

        # Clear fields
        for widget in [fname_entry, lname_entry, email_entry, password_entry,
                       phone_entry, department_entry, position_entry, experience_entry, salary_entry]:
            widget.delete(0, "end")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to add employee: {str(e)}")

# === Buttons ===
btn_frame = ctk.CTkFrame(root, fg_color="#92E3B4")
btn_frame.pack(pady=10)

ctk.CTkButton(btn_frame, text="Add Employee", command=add_employee, width=180, height=40,
              fg_color="white", text_color="black", font=("Arial", 14)).pack(side="left", padx=10)

ctk.CTkButton(btn_frame, text="← Back", command=lambda: [root.destroy(), subprocess.Popen(["python", "admin_dashboard.py", admin_email])],
              fg_color="white", hover_color="#e0e0e0", text_color="black", width=100, height=40).pack(side="left")

# === Main Loop ===
root.mainloop()
