import tkinter as tk
import subprocess
from tkinter import messagebox
import sys
from database import get_db_connection
from tkinter import StringVar
from tkinter import ttk
import customtkinter as ctk
import os
import csv
from datetime import datetime

# === Get user email ===
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)



# === New DB Utility ===
def get_all_employees():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, first_name, last_name FROM User")
    data = cursor.fetchall()
    conn.close()
    return data

def get_all_departments():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT department FROM Employee")
    data = cursor.fetchall()
    conn.close()
    return [d[0] for d in data]


def get_all_positions():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT position FROM Employee")
    data = cursor.fetchall()
    conn.close()
    return [p[0] for p in data]

# === Fetch full name from DB ===
def get_user_full_name(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT first_name, last_name FROM User WHERE user_id = %s", (user_id,))
    name = cursor.fetchone()
    conn.close()
    return name if name else ("Unknown", "User")

def export_to_csv():
    selected_emp = emp_var.get()

    # Generate filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if selected_emp != "All":
        first_last = selected_emp.split(" (ID")[0].replace(" ", "_")
        filename = f"timesheet_{first_last}_{timestamp}.csv"
    else:
        filename = f"timesheet_all_{timestamp}.csv"

    # Fetch rows from Treeview
    rows = [tree.item(item)["values"] for item in tree.get_children()]

    if not rows or rows[0][0] == "No":
        messagebox.showwarning("No Data", "There is no data to export.")
        return

    try:
        with open(filename, mode="w", newline="") as file:
            writer = csv.writer(file)

            # ==== Write Title Line ====
            if selected_emp != "All":
                report_title = f"Timesheet Report - {selected_emp.split(' (ID')[0]}"
            else:
                report_title = "Timesheet Report - All Employees"
            
            writer.writerow([report_title])
            writer.writerow([])  # Blank line

            # ==== Write Header Row ====
            writer.writerow(["First Name", "Last Name", "Date", "Clock-In", "Clock-Out", "Total Hours"])

            # ==== Write Data ====
            writer.writerows(rows)

        messagebox.showinfo("Export Successful", f"Time sheet exported to '{filename}'")

    except Exception as e:
        messagebox.showerror("Export Failed", str(e))


def fetch_filtered_time_sheet(user_id=None, departments=None, positions=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        SELECT 
            DATE(CONVERT_TZ(T.clock_in, '+00:00', '-04:00')) AS work_date,
            TIME(CONVERT_TZ(T.clock_in, '+00:00', '-04:00')) AS clock_in_est,
            TIME(CONVERT_TZ(T.clock_out, '+00:00', '-04:00')) AS clock_out_est,
            T.total_hours,
            U.first_name,
            U.last_name
        FROM Time_Tracking T
        JOIN User U ON T.user_id = U.user_id
        JOIN Employee E ON T.user_id = E.user_id
        WHERE 1=1
    """
    params = []

    if user_id:
        query += " AND T.user_id = %s"
        params.append(user_id)
    if departments:
        query += " AND E.department = %s"
        params.append(departments)
    if positions:
        query += " AND E.position = %s"
        params.append(positions)

    query += " ORDER BY T.clock_in DESC"
    cursor.execute(query, tuple(params))
    data = cursor.fetchall()
    conn.close()
    return data 

# === UI Setup ===
root = tk.Tk()
root.title("Admin - Time Sheet Viewer")
root.geometry("900x600")
root.configure(bg="#C7E8CA")

tk.Label(root, text="🕒 Admin Time Sheet Viewer", font=("Arial", 18, "bold"), bg="#C7E8CA").pack(pady=10)

# === Dropdown Selections ===
filter_frame = tk.Frame(root, bg="#C7E8CA")
filter_frame.pack(pady=5)

emp_list = get_all_employees()
dept_list = get_all_departments()
pos_list = get_all_positions()

emp_var = StringVar()
dept_var = StringVar()
pos_var = StringVar()

tk.Label(filter_frame, text="Employee:", bg="#C7E8CA").grid(row=0, column=0, padx=5)
emp_dropdown = ttk.Combobox(filter_frame, textvariable=emp_var, state="readonly", width=25)
emp_dropdown["values"] = ["All"] + [f"{fn} {ln} (ID:{uid})" for uid, fn, ln in emp_list]
emp_dropdown.current(0)
emp_dropdown.grid(row=0, column=1)

tk.Label(filter_frame, text="Department:", bg="#C7E8CA").grid(row=0, column=2, padx=5)
dept_dropdown = ttk.Combobox(filter_frame, textvariable=dept_var, state="readonly", width=20)
dept_dropdown["values"] = ["All"] + dept_list
dept_dropdown.current(0)
dept_dropdown.grid(row=0, column=3)

tk.Label(filter_frame, text="Position:", bg="#C7E8CA").grid(row=0, column=4, padx=5)
pos_dropdown = ttk.Combobox(filter_frame, textvariable=pos_var, state="readonly", width=20)
pos_dropdown["values"] = ["All"] + pos_list
pos_dropdown.current(0)
pos_dropdown.grid(row=0, column=5)

# === Treeview Setup ===
frame = tk.Frame(root, bg="white", bd=2, relief="groove")
frame.place(x=50, y=130, width=800, height=350)

tree_scroll = tk.Scrollbar(frame)
tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)

style = ttk.Style()
style.theme_use("default")
style.configure("Treeview.Heading", background="green", foreground="white", font=("Helvetica", 10, "bold"))

tree = ttk.Treeview(frame, yscrollcommand=tree_scroll.set, 
                    columns=("First Name", "Last Name", "Date", "Clock-In", "Clock-Out", "Total Hours"),
                    show="headings", height=15)
tree.pack(fill=tk.BOTH, expand=True)
tree_scroll.config(command=tree.yview)

for col in tree["columns"]:
    tree.heading(col, text=col)
    tree.column(col, anchor="center", width=120)

# === Refresh Table ===
def load_time_sheet():
    tree.delete(*tree.get_children())

    selected_emp = emp_var.get()
    selected_dept = dept_var.get()
    selected_pos = pos_var.get()

    uid = None
    if selected_emp != "All":
        uid = int(selected_emp.split("ID:")[1].strip(")"))

    dept = selected_dept if selected_dept != "All" else None
    pos = selected_pos if selected_pos != "All" else None

    data = fetch_filtered_time_sheet(uid, dept, pos)

    if data:
        for row in data:
            tree.insert("", tk.END, values=(row[4], row[5], row[0], row[1], row[2], row[3]))
    else:
        tree.insert("", tk.END, values=("No", "records", "", "", "", ""))

# === Load Button ===
ctk.CTkButton(root, text="🔄 Load Time Sheet", command=load_time_sheet, font=("Arial", 14, "bold"),
              fg_color="#4CAF50", hover_color="#388E3C", corner_radius=10).pack(pady=10)

# === Back Button ===
def go_back_to_dashboard():
    root.destroy()
    subprocess.Popen(["python", "admin_dashboard.py", user_email])

ctk.CTkButton(root, text="← Back", command=go_back_to_dashboard, font=("Arial", 16, "bold"),
              fg_color="gray", hover_color="darkgray", corner_radius=12).place(x=400, y=500)

ctk.CTkButton(root, text="📁 Export to CSV", command=export_to_csv, font=("Arial", 14, "bold"),
              fg_color="#2196F3", hover_color="#1976D2", corner_radius=10).place(x=400, y=550)


# Initial Load
load_time_sheet()

root.mainloop()
