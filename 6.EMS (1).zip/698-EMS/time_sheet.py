import tkinter as tk
import subprocess
from tkinter import messagebox, filedialog
from tkinter import ttk
import customtkinter as ctk
from database import get_db_connection
import sys
import csv
import os

# === Get user email ===
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# === DB Utilities ===
def get_user_id(email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM User WHERE email=%s", (email,))
    user = cursor.fetchone()
    conn.close()
    return user[0] if user else None

def fetch_time_sheet(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT 
            DATE(CONVERT_TZ(clock_in, '+00:00', '-04:00')) AS work_date,
            TIME(CONVERT_TZ(clock_in, '+00:00', '-04:00')) AS clock_in_est,
            TIME(CONVERT_TZ(clock_out, '+00:00', '-04:00')) AS clock_out_est,
            total_hours
        FROM Time_Tracking 
        WHERE user_id = %s
        ORDER BY clock_in DESC
    """, (user_id,))
    records = cursor.fetchall()
    conn.close()
    return records

def go_back():
    root.destroy()
    subprocess.Popen(["python", "employee_dashboard.py", user_email])

# === Fetch full name from DB ===
def get_user_full_name(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT first_name, last_name FROM User WHERE user_id = %s", (user_id,))
    name = cursor.fetchone()
    conn.close()
    return name if name else ("Unknown", "User")

# === Auto-export to CSV with full name ===
def export_to_csv():
    if not time_sheet_data:
        messagebox.showinfo("No Data", "There is no data to export.")
        return

    first_name, last_name = get_user_full_name(user_id)
    filename = f"time_sheet_{first_name}_{last_name}.csv".replace(" ", "_")
    file_path = os.path.join(os.getcwd(), filename)

    try:
        with open(file_path, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Clock-In", "Clock-Out", "Total Hours"])
            writer.writerows(time_sheet_data)
        messagebox.showinfo("Export Successful", f"Time sheet exported as:\n{file_path}")
    except Exception as e:
        messagebox.showerror("Export Failed", str(e))

# === Fetch User + Data ===
user_id = get_user_id(user_email)
if not user_id:
    messagebox.showerror("Error", "User not found!")
    sys.exit(1)

time_sheet_data = fetch_time_sheet(user_id)

# === UI Setup ===
root = tk.Tk()
root.title("Time Sheet")
root.geometry("700x500")
root.configure(bg="#C7E8CA")  # Background green

# === Title ===
tk.Label(root, text="Time Sheet", font=("Arial", 18, "bold"), bg="#C7E8CA", fg="#333").place(x=280, y=20)

# === Treeview Frame ===
frame = tk.Frame(root, bg="white", bd=2, relief="groove")
frame.place(x=50, y=80, width=600, height=320)

# === Treeview Scrollbar ===
tree_scroll = tk.Scrollbar(frame)
tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)

# === Configure Treeview Header Style ===
style = ttk.Style()
style.theme_use("default")  # This is important!
style.configure("Treeview.Heading", background="green", foreground="white", font=("Helvetica", 10, "bold"))

# === Treeview ===
tree = ttk.Treeview(frame, yscrollcommand=tree_scroll.set, columns=("Date", "Clock-In", "Clock-Out", "Total Hours"), show="headings", height=15)
tree.pack(fill=tk.BOTH, expand=True)
tree_scroll.config(command=tree.yview)

# === Treeview Column Setup ===
tree.heading("Date", text="Date")
tree.heading("Clock-In", text="Clock-In")
tree.heading("Clock-Out", text="Clock-Out")
tree.heading("Total Hours", text="Total Hours")

tree.column("Date", width=140, anchor="center")
tree.column("Clock-In", width=140, anchor="center")
tree.column("Clock-Out", width=140, anchor="center")
tree.column("Total Hours", width=140, anchor="center")

# === Insert Data ===
if time_sheet_data:
    for row in time_sheet_data:
        tree.insert("", tk.END, values=row)
else:
    tree.insert("", tk.END, values=("No records", "", "", ""))

# === Export to CSV Button ===
ctk.CTkButton(root, text="Export to CSV", command=export_to_csv, font=("Arial", 16, "bold"),
              fg_color="#4CAF50", hover_color="#388E3C", corner_radius=12).place(x=500, y=20)

# === Back Button ===
ctk.CTkButton(root, text="← Back", command=go_back, font=("Arial", 20, "bold"),
              fg_color="gray", hover_color="darkgray", width=12, corner_radius=12).place(x=290, y=430)

# === Launch App ===
root.mainloop()
