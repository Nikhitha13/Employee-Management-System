-- Create User Table
CREATE TABLE IF NOT EXISTS User (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL CHECK (email LIKE '%@gmail.com'),
    password VARCHAR(255) NOT NULL CHECK (CHAR_LENGTH(password) >= 8),
    phone VARCHAR(20) NOT NULL CHECK (CHAR_LENGTH(phone) BETWEEN 10 AND 20),
    role ENUM('employee', 'admin') DEFAULT 'employee',
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- Create Employee Table
CREATE TABLE IF NOT EXISTS Employee (
    user_id INT PRIMARY KEY,
    position VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    experience INT NOT NULL CHECK (experience >= 0),
    address TEXT,
    job_info TEXT,
    skills TEXT,
    salary DECIMAL(10,2) NOT NULL CHECK (salary >= 0),
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
);

-- Create Admin Table
CREATE TABLE IF NOT EXISTS Admin (
    user_id INT PRIMARY KEY,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
);

-- Create Time_Tracking Table
CREATE TABLE IF NOT EXISTS Time_Tracking (
    tracking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    clock_in TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    clock_out TIMESTAMP NULL,
    total_hours DECIMAL(5,2) GENERATED ALWAYS AS 
        (TIMESTAMPDIFF(SECOND, clock_in, clock_out) / 3600) STORED,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
);

-- Insert 30 Users (Indian Names)
INSERT INTO User (first_name, last_name, email, password, phone, role, status) VALUES
('Admin', 'One', 'admin@gmail.com', 'admin1234', '+919999999999', 'admin', 'active'),
('Navya', 'Gali', 'navya@gmail.com', 'navya123456', '+919876543210', 'employee', 'active'),
('Rahul', 'Sharma', 'rahul.sharma1@gmail.com', 'password123', '+919000000001', 'employee', 'active'),
('Priya', 'Patel', 'priya.patel2@gmail.com', 'password123', '+919000000002', 'employee', 'inactive'),
('Amit', 'Verma', 'amit.verma3@gmail.com', 'password123', '+919000000003', 'employee', 'active'),
('Anjali', 'Singh', 'anjali.singh4@gmail.com', 'password123', '+919000000004', 'employee', 'active'),
('Vikram', 'Reddy', 'vikram.reddy5@gmail.com', 'password123', '+919000000005', 'employee', 'active'),
('Sneha', 'Naidu', 'sneha.naidu6@gmail.com', 'password123', '+919000000006', 'employee', 'inactive'),
('Sahil', 'Mishra', 'sahil.mishra7@gmail.com', 'password123', '+919000000007', 'employee', 'active'),
('Pooja', 'Iyer', 'pooja.iyer8@gmail.com', 'password123', '+919000000008', 'employee', 'active'),
('Rohan', 'Chopra', 'rohan.chopra9@gmail.com', 'password123', '+919000000009', 'employee', 'inactive'),
('Kavya', 'Gupta', 'kavya.gupta10@gmail.com', 'password123', '+919000000010', 'employee', 'active'),
('Arjun', 'Joshi', 'arjun.joshi11@gmail.com', 'password123', '+919000000011', 'employee', 'active'),
('Nisha', 'Bansal', 'nisha.bansal12@gmail.com', 'password123', '+919000000012', 'employee', 'active'),
('Manish', 'Kapoor', 'manish.kapoor13@gmail.com', 'password123', '+919000000013', 'employee', 'inactive'),
('Divya', 'Deshmukh', 'divya.deshmukh14@gmail.com', 'password123', '+919000000014', 'employee', 'active'),
('Siddharth', 'Shetty', 'siddharth.shetty15@gmail.com', 'password123', '+919000000015', 'employee', 'active'),
('Aishwarya', 'Mehta', 'aishwarya.mehta16@gmail.com', 'password123', '+919000000016', 'employee', 'active'),
('Karan', 'Saxena', 'karan.saxena17@gmail.com', 'password123', '+919000000017', 'employee', 'inactive'),
('Neha', 'Rastogi', 'neha.rastogi18@gmail.com', 'password123', '+919000000018', 'employee', 'active'),
('Abhishek', 'Tripathi', 'abhishek.tripathi19@gmail.com', 'password123', '+919000000019', 'employee', 'active'),
('Ishita', 'Pillai', 'ishita.pillai20@gmail.com', 'password123', '+919000000020', 'employee', 'active'),
('Yash', 'Kulkarni', 'yash.kulkarni21@gmail.com', 'password123', '+919000000021', 'employee', 'active'),
('Pallavi', 'Bhattacharya', 'pallavi.bhattacharya22@gmail.com', 'password123', '+919000000022', 'employee', 'active'),
('Varun', 'Chatterjee', 'varun.chatterjee23@gmail.com', 'password123', '+919000000023', 'employee', 'active'),
('Tanvi', 'Dutta', 'tanvi.dutta24@gmail.com', 'password123', '+919000000024', 'employee', 'active'),
('Suresh', 'Menon', 'suresh.menon25@gmail.com', 'password123', '+919000000025', 'employee', 'inactive'),
('Shruti', 'Ghosh', 'shruti.ghosh26@gmail.com', 'password123', '+919000000026', 'employee', 'active'),
('Nikhil', 'Das', 'nikhil.das27@gmail.com', 'password123', '+919000000027', 'employee', 'active'),
('Meera', 'Nair', 'meera.nair28@gmail.com', 'password123', '+919000000028', 'employee', 'active');

-- Insert into Admin Table
INSERT INTO Admin (user_id)
SELECT user_id FROM User WHERE email = 'admin@gmail.com';

-- Insert into Employee Table
INSERT INTO Employee (user_id, position, department, experience, address, job_info, skills, salary)
SELECT user_id, 'Software Developer', 'IT', 2, 'Bangalore, India', 'Develops backend and frontend.', 'Python, Java, SQL', 600000.00
FROM User
WHERE role = 'employee';

-- Insert 30 rows into Time_Tracking (Manual clock-in and clock-out)
INSERT INTO Time_Tracking (user_id, clock_in, clock_out) VALUES
(2, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 1 HOUR),
(3, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(4, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 2 HOUR),
(5, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 3 HOUR),
(6, NOW() - INTERVAL 10 HOUR, NOW() - INTERVAL 1 HOUR),
(7, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 2 HOUR),
(8, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(9, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 3 HOUR),
(10, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 1 HOUR),
(11, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 2 HOUR),
(12, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 1 HOUR),
(13, NOW() - INTERVAL 6 HOUR, NOW() - INTERVAL 2 HOUR),
(14, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(15, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 3 HOUR),
(16, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 2 HOUR),
(17, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(18, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 2 HOUR),
(19, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(20, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 1 HOUR),
(21, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 2 HOUR),
(22, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(23, NOW() - INTERVAL 6 HOUR, NOW() - INTERVAL 1 HOUR),
(24, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 3 HOUR),
(25, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 2 HOUR),
(26, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 1 HOUR),
(27, NOW() - INTERVAL 8 HOUR, NOW() - INTERVAL 1 HOUR),
(28, NOW() - INTERVAL 6 HOUR, NOW() - INTERVAL 1 HOUR),
(29, NOW() - INTERVAL 7 HOUR, NOW() - INTERVAL 2 HOUR),
(30, NOW() - INTERVAL 9 HOUR, NOW() - INTERVAL 1 HOUR);
