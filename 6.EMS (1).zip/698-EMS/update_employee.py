import sys
import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox
import subprocess
from database import get_db_connection

# === Theme Setup ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Email from CLI ===
if len(sys.argv) > 1:
    email = sys.argv[1]
else:
    messagebox.showerror("Error", "Email not provided!")
    sys.exit(1)

# === Fetch Employee Data ===
def get_employee_details_by_email(email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.user_id, u.first_name, u.last_name, u.email, u.phone, u.status,
               e.position, e.department, e.experience, e.address,
               e.job_info, e.skills, e.salary
        FROM User u
        JOIN Employee e ON u.user_id = e.user_id
        WHERE u.email = %s
    """, (email,))
    data = cursor.fetchone()
    conn.close()
    return data

emp = get_employee_details_by_email(email)
if not emp:
    messagebox.showerror("Error", "Employee not found!")
    sys.exit(1)

user_id = emp[0]

# === Save Updated Details ===
def save_details():
    new_vals = [e.get().strip() for e in entries]
    new_status = status_var.get().strip()

    if not all(new_vals) or not new_status:
        messagebox.showerror("Error", "All fields must be filled.")
        return

    try:
        experience = int(new_vals[6])
        salary = float(new_vals[10])
    except ValueError:
        messagebox.showerror("Validation Error", "Experience must be an integer and Salary must be a number.")
        return

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check for duplicate email
        cursor.execute("SELECT COUNT(*) FROM User WHERE email=%s AND user_id != %s", (new_vals[2], user_id))
        if cursor.fetchone()[0] > 0:
            messagebox.showerror("Error", "Email already exists!")
            conn.close()
            return

        # Update User table
        cursor.execute("""
            UPDATE User 
            SET first_name=%s, last_name=%s, email=%s, phone=%s, status=%s 
            WHERE user_id=%s
        """, (new_vals[0], new_vals[1], new_vals[2], new_vals[3], new_status, user_id))

        # Update Employee table
        cursor.execute("""
            UPDATE Employee 
            SET position=%s, department=%s, experience=%s, address=%s,
                job_info=%s, skills=%s, salary=%s 
            WHERE user_id=%s
        """, (new_vals[4], new_vals[5], experience, new_vals[7],
              new_vals[8], new_vals[9], salary, user_id))

        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Employee details updated.")
        root.destroy()
        subprocess.Popen(["python", "employee_management.py"])

    except Exception as e:
        messagebox.showerror("Database Error", str(e))

# === UI Setup ===
root = ctk.CTk()
root.geometry("600x700")
root.title("Update Employee")
root.configure(fg_color="#92E3B4")

ctk.CTkLabel(root, text="Update Employee", font=("Arial", 22, "bold"),
             text_color="black").pack(pady=20)

# === Main Form Frame ===
form_frame = ctk.CTkFrame(root, fg_color="white")
form_frame.pack(padx=30, pady=10, fill="both", expand=True)

labels = [
    "First Name", "Last Name", "Email", "Phone",
    "Position", "Department", "Experience", "Address",
    "Job Info", "Skills", "Salary"
]

mapped_fields = [
    emp[1],  # First Name
    emp[2],  # Last Name
    emp[3],  # Email
    emp[4],  # Phone
    emp[6],  # Position
    emp[7],  # Department
    emp[8],  # Experience
    emp[9],  # Address
    emp[10], # Job Info
    emp[11], # Skills
    emp[12], # Salary
]

entries = []
for i, label in enumerate(labels):
    row = i
    ctk.CTkLabel(form_frame, text=label, font=("Arial", 13), text_color="black").grid(row=row, column=0, padx=10, pady=6, sticky="w")
    entry = ctk.CTkEntry(form_frame, width=400)
    entry.insert(0, str(mapped_fields[i]))
    entry.grid(row=row, column=1, padx=10, pady=6, sticky="w")
    entries.append(entry)

# === Status Dropdown ===
status_label_row = len(labels)
ctk.CTkLabel(form_frame, text="Status", font=("Arial", 13), text_color="black").grid(row=status_label_row, column=0, padx=10, pady=10, sticky="w")
status_var = tk.StringVar(value=emp[5])
status_dropdown = ctk.CTkOptionMenu(form_frame, values=["active", "inactive"],
                                    variable=status_var, width=400)
status_dropdown.grid(row=status_label_row, column=1, padx=10, pady=10, sticky="w")

# === Buttons ===
button_row = status_label_row + 1
button_frame = ctk.CTkFrame(root, fg_color="#92E3B4")
button_frame.pack(pady=40)

ctk.CTkButton(button_frame, text="💾 Save", command=save_details,
              fg_color="#4CAF50", width=140).pack(side="left", padx=20)

ctk.CTkButton(button_frame, text="← Back",
              command=lambda: (root.destroy(), subprocess.Popen(["python", "employee_management.py", "admin@gmail.com"])),
              fg_color="gray", width=140).pack(side="right", padx=20)

# === Start UI ===
root.mainloop()
