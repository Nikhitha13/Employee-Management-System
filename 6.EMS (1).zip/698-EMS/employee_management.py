# employee_records.py
import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox
import subprocess
from PIL import Image
from database import get_db_connection

# === Setup ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

root = ctk.CTk()
root.geometry("900x600")  # Increased width
root.title("Employee Records")
root.configure(fg_color="white")

# === Header ===
header = ctk.CTkFrame(root, height=60, fg_color="#A4DE96", corner_radius=0)
header.pack(fill=tk.X)

ctk.CTkLabel(header, text="Employee Records", text_color="black", font=("Arial", 20, "bold")).pack(side=tk.LEFT, padx=20, pady=15)

try:
    admin_img = ctk.CTkImage(light_image=Image.open("images/admin_pic.png").resize((40, 40)))
    ctk.CTkLabel(header, image=admin_img, text="").pack(side=tk.RIGHT, padx=20, pady=10)
except:
    ctk.CTkLabel(header, text="👤", font=("Arial", 22)).pack(side=tk.RIGHT, padx=20, pady=10)

# === Search Frame ===
search_frame = ctk.CTkFrame(root, fg_color="white")
search_frame.pack(pady=(10, 0))

search_var = tk.StringVar()
search_entry = ctk.CTkEntry(search_frame, textvariable=search_var, placeholder_text="🔍 Search Employee", width=500)
search_entry.pack(side=tk.LEFT, padx=10)

def filter_employees():
    render_employees(search_var.get())

ctk.CTkButton(search_frame, text="Search", command=filter_employees, width=80).pack(side=tk.LEFT)

# === Column Headers (fixed alignment) ===
column_frame = tk.Frame(root, bg="white")
column_frame.pack(pady=(5, 0), fill=tk.X, padx=20)

headers = ["#", "First Name", "Last Name", "Email"]
widths = [10, 20, 20, 60]  # Adjusted column widths properly

for idx, (header, w) in enumerate(zip(headers, widths)):
    tk.Label(column_frame, text=header, bg="white", font=("Arial", 12, "bold"), width=w, anchor="w").grid(row=0, column=idx, sticky="w", padx=2)

# === Scrollable Employee Frame ===
table_frame = tk.Frame(root, bg="white")
table_frame.pack(pady=(5, 0), fill=tk.BOTH, expand=True, padx=20)

canvas = tk.Canvas(table_frame, bg="white", highlightthickness=0)
scrollbar = tk.Scrollbar(table_frame, orient=tk.VERTICAL, command=canvas.yview)
scrollable_frame = tk.Frame(canvas, bg="white")

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(
        scrollregion=canvas.bbox("all")
    )
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# === Variables to track selected employee ===
selected_email = tk.StringVar()
selected_row = None  # Track selected row widget

# === Fetch Employees ===
def fetch_employees(query=""):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.user_id, u.first_name, u.last_name, u.email
        FROM User u
        JOIN Employee e ON u.user_id = e.user_id
        WHERE u.first_name LIKE %s OR u.last_name LIKE %s OR u.email LIKE %s
    """, (f"%{query}%", f"%{query}%", f"%{query}%"))
    employees = cursor.fetchall()
    conn.close()
    return employees

# === Handle selecting a row ===
def select_row(email, row_frame):
    global selected_row
    selected_email.set(email)

    # Reset previous selected row color
    if selected_row:
        selected_row.config(bg="white")
        for child in selected_row.winfo_children():
            child.config(bg="white")

    # Highlight new selected row
    row_frame.config(bg="#D1E7DD")  # Light green highlight
    for child in row_frame.winfo_children():
        child.config(bg="#D1E7DD")

    selected_row = row_frame

# === Render Employees ===
def render_employees(filter_term=""):
    global selected_row
    selected_row = None
    selected_email.set("")
    for widget in scrollable_frame.winfo_children():
        widget.destroy()

    employees = fetch_employees(filter_term)

    for idx, emp in enumerate(employees, start=1):
        row_frame = tk.Frame(scrollable_frame, bg="white", highlightbackground="black", highlightthickness=1)
        row_frame.pack(fill="x", pady=1)

        tk.Label(row_frame, text=str(idx), bg="white", font=("Arial", 11), width=10, anchor="w").grid(row=0, column=0, padx=2)
        tk.Label(row_frame, text=emp[1], bg="white", font=("Arial", 11), width=20, anchor="w").grid(row=0, column=1, padx=2)
        tk.Label(row_frame, text=emp[2], bg="white", font=("Arial", 11), width=20, anchor="w").grid(row=0, column=2, padx=2)
        tk.Label(row_frame, text=emp[3], bg="white", font=("Arial", 11), width=60, anchor="w").grid(row=0, column=3, padx=2)

        # Selectable row
        row_frame.bind("<Button-1>", lambda e, email=emp[3], frame=row_frame: select_row(email, frame))
        for child in row_frame.winfo_children():
            child.bind("<Button-1>", lambda e, email=emp[3], frame=row_frame: select_row(email, frame))

# === Update Selected Employee ===
def update_selected_employee():
    email = selected_email.get()
    if email:
        root.destroy()
        subprocess.Popen(["python", "update_employee.py", email])
    else:
        messagebox.showerror("No Selection", "Please select an employee to update.")

# === Bottom Buttons ===
button_frame = ctk.CTkFrame(root, fg_color="white")
button_frame.pack(pady=(10, 10))

update_btn = ctk.CTkButton(button_frame, text="Update Selected", fg_color="#A4DE96", text_color="black",
                           hover_color="#7ED9A2", font=("Arial", 12), width=140, command=update_selected_employee)
update_btn.pack(side=tk.LEFT, padx=20)

def go_back():
    root.destroy()
    subprocess.Popen(["python", "admin_dashboard.py", "admin@gmail.com"])

back_btn = ctk.CTkButton(button_frame, text="Back", fg_color="#e0e0e0", text_color="black",
                         hover_color="#d0d0d0", font=("Arial", 12), width=80,
                         command=go_back)
back_btn.pack(side=tk.LEFT)

# === First render ===
render_employees()

root.mainloop()
