import customtkinter as ctk
import tkinter as tk
import subprocess
import sys
from PIL import Image
from tkinter import messagebox
import mysql.connector
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.ticker import MaxNLocator 
from database import get_db_connection

# === Theme Setup ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Get user email ===
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# === Navigation Functions ===
def open_employee_management():
    root.destroy()
    subprocess.Popen(["python", "employee_management.py", user_email])
    
def open_add_employee():
    root.destroy()
    subprocess.Popen(["python", "add_employee.py", user_email])

def open_time_logs():
    root.destroy()
    subprocess.Popen(["python", "timesheet_logs.py", user_email])

def open_view_all_employees():
    root.destroy()
    subprocess.Popen(["python", "view_all_employees.py", user_email])

def go_back():
    root.destroy()
    subprocess.Popen(["python", "login.py"])

# === Count Functions ===
def fetch_counts():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Total active employees
    cursor.execute("SELECT COUNT(*) FROM User WHERE role='employee' AND status = 'active'")
    total_employees = cursor.fetchone()[0]

    # Total inactive employees
    cursor.execute("SELECT COUNT(*) FROM User WHERE role='employee' AND status = 'inactive'")
    total_inactive = cursor.fetchone()[0]

    conn.close()
    return total_employees, total_inactive

# === Bar Chart ===
def draw_graph(total_employees, total_fired):
    fig, ax = plt.subplots(figsize=(3.5, 3), dpi=100)
    ax.bar(["Employees", "Inactive"], [total_employees, total_fired], color=["#4CAF50", "#F44336"])
    
    # Remove Y-axis label and ticks
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax.set_ylabel("")
    ax.tick_params(axis='y', which='both', left=False, right=False, labelleft=False)

    # Remove top, left, and right borders (spines)
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    # Keep only bottom (x-axis) border

    # Add value labels above bars
    for i, v in enumerate([total_employees, total_fired]):
        ax.text(i, v + 0.1, str(v), ha='center', fontweight='bold')

    chart = FigureCanvasTkAgg(fig, master=main)
    chart.draw()
    chart.get_tk_widget().place(x=250, y=380)



# === Root Window ===
root = ctk.CTk()
root.title("Admin Dashboard")
root.geometry("1000x600")
root.resizable(False, False)

# === Sidebar ===
sidebar = ctk.CTkFrame(root, width=230, height=600, fg_color="#92E3B4", corner_radius=0)
sidebar.place(x=0, y=0)

ctk.CTkLabel(sidebar, text="Admin Dashboard", font=("Arial", 20, "bold"), text_color="black").place(x=20, y=20)

icon_size = (22, 22)
home_icon = ctk.CTkImage(light_image=Image.open("images/home_icon.png").resize(icon_size))
emp_icon = ctk.CTkImage(light_image=Image.open("images/manager.png").resize(icon_size))
time_icon = ctk.CTkImage(light_image=Image.open("images/clock_icon.png").resize(icon_size))
signout_icon = ctk.CTkImage(light_image=Image.open("images/signout_icon.png").resize(icon_size))
user_icon = ctk.CTkImage(light_image=Image.open("images/add.png").resize(icon_size))

ctk.CTkButton(sidebar, text="Home", image=home_icon, anchor="w", compound="left", fg_color="#92E3B4",
              hover_color="#7ED9A2", text_color="black", font=("Arial", 14), corner_radius=10, width=180).place(x=20, y=80)

ctk.CTkButton(sidebar, text="Employee Management", image=emp_icon, anchor="w", compound="left", fg_color="#92E3B4",
              hover_color="#7ED9A2", text_color="black", font=("Arial", 14), corner_radius=10,
              command=open_employee_management, width=180).place(x=20, y=130)

ctk.CTkButton(sidebar, text="Time Log", image=time_icon, anchor="w", compound="left", fg_color="#92E3B4",
              hover_color="#7ED9A2", text_color="black", font=("Arial", 14), corner_radius=10,
              command=open_time_logs, width=180).place(x=20, y=180)

ctk.CTkLabel(sidebar, text="Admin", text_color="black", font=("Arial", 14)).place(x=90, y=500)
ctk.CTkButton(sidebar, text="Sign Out", image=signout_icon, compound="left", fg_color="#92E3B4",
              hover_color="#7ED9A2", text_color="black", font=("Arial", 14), corner_radius=10,
              command=go_back, width=180).place(x=20, y=540)

# === Main Content ===
main = ctk.CTkFrame(root, width=770, height=600, fg_color="white")
main.place(x=230, y=0)

ctk.CTkLabel(main, text="Employee Records Management", font=("Arial", 18, "bold"), text_color="black").place(x=220, y=50)
ctk.CTkButton(main, text="← Back", fg_color="white", hover_color="#e0e0e0",
              text_color="black", font=("Arial", 14), corner_radius=10,
              command=go_back, width=80, height=30).place(x=670, y=15)

ctk.CTkFrame(main, height=5, width=780, fg_color="#92E3B4").place(x=0, y=100)

# === Action Buttons ===
add_icon = ctk.CTkImage(Image.open("images/add.png").resize((30, 30)))
view_icon = ctk.CTkImage(Image.open("images/dashboard.png").resize((30, 30)))
update_icon = ctk.CTkImage(Image.open("images/update-list.png").resize((30, 30)))

ctk.CTkButton(main, text="Add Employee", image=add_icon, compound="left", width=200, height=50,
              font=("Arial", 13, "bold"), fg_color="#92E3B4", hover_color="#7ED9A2",
              text_color="black", command=open_add_employee).place(x=80, y=140)

ctk.CTkButton(main, text="View All Employees", image=view_icon, compound="left", width=200, height=50,
              font=("Arial", 13, "bold"), fg_color="#92E3B4", hover_color="#7ED9A2",
              text_color="black", command=open_view_all_employees).place(x=285, y=140)

ctk.CTkButton(main, text="Update Employee", image=update_icon, compound="left", width=200, height=50,
              font=("Arial", 13, "bold"), fg_color="#92E3B4", hover_color="#7ED9A2",
              text_color="black", command=open_employee_management).place(x=490, y=140)

# === KPIs ===
total_emp, total_fired = fetch_counts()

ctk.CTkLabel(main, text=f"Total Employees: {total_emp}", font=("Arial", 14, "bold"), text_color="black").place(x=80, y=220)
ctk.CTkLabel(main, text=f"Inactive Employees: {total_fired}", font=("Arial", 14, "bold"), text_color="black").place(x=80, y=260)

# === Bar Chart ===
draw_graph(total_emp, total_fired)

# === Run App ===
root.mainloop()
