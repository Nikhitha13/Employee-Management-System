import customtkinter as ctk
from tkinter import messagebox
import sys
import subprocess
from database import get_db_connection

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Email from command line ===
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# === DB Update ===
def update_password(email, current_pw, new_pw):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT password FROM User WHERE email = %s", (email,))
    result = cursor.fetchone()

    if not result or result[0] != current_pw:
        conn.close()
        return False, "Current password is incorrect."

    cursor.execute("UPDATE User SET password = %s WHERE email = %s", (new_pw, email))
    conn.commit()
    conn.close()
    return True, "Password updated successfully."

# === Save Button Logic ===
def change_password():
    current = current_entry.get().strip()
    new = new_entry.get().strip()
    confirm = confirm_entry.get().strip()

    if not current or not new or not confirm:
        messagebox.showerror("Error", "All fields are required.")
        return

    if new != confirm:
        messagebox.showerror("Error", "New passwords do not match.")
        return

    success, msg = update_password(user_email, current, new)
    if success:
        messagebox.showinfo("Success", msg)
        root.destroy()
        subprocess.Popen(["python", "login.py"])  # ✅ Redirect to login
    else:
        messagebox.showerror("Failed", msg)

# === UI Setup ===
root = ctk.CTk()
root.title("Change Password")
root.geometry("600x400")
root.configure(fg_color="#92E3B4")

ctk.CTkLabel(root, text="Change Password", font=("Arial", 22, "bold"), text_color="black").pack(pady=30)

form_frame = ctk.CTkFrame(root, fg_color="white")
form_frame.pack(pady=20, padx=30, fill="both", expand=True)

ctk.CTkLabel(form_frame, text="Current Password", font=("Arial", 13)).grid(row=0, column=0, padx=10, pady=10, sticky="w")
current_entry = ctk.CTkEntry(form_frame, width=300, show="*")
current_entry.grid(row=0, column=1, padx=10, pady=10)

ctk.CTkLabel(form_frame, text="New Password", font=("Arial", 13)).grid(row=1, column=0, padx=10, pady=10, sticky="w")
new_entry = ctk.CTkEntry(form_frame, width=300, show="*")
new_entry.grid(row=1, column=1, padx=10, pady=10)

ctk.CTkLabel(form_frame, text="Confirm New Password", font=("Arial", 13)).grid(row=2, column=0, padx=10, pady=10, sticky="w")
confirm_entry = ctk.CTkEntry(form_frame, width=300, show="*")
confirm_entry.grid(row=2, column=1, padx=10, pady=10)

ctk.CTkButton(root, text="Save", command=change_password, width=120, fg_color="#4CAF50").pack(pady=10)

ctk.CTkButton(root, text="← Back",
              command=lambda: (root.destroy(), subprocess.Popen(["python", "employee_dashboard.py", user_email])),
              width=120, fg_color="gray").pack(pady=5)

root.mainloop()
