import tkinter as tk
from PIL import Image, ImageTk
from tkinter import PhotoImage
from tkinter import messagebox
import subprocess
import sys
import customtkinter as ctk
from database import get_db_connection

# === Setup CustomTkinter ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("green")

# === Get user email ===
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# === DB Functions ===
def get_user_id(email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM User WHERE email=%s", (email,))
    user = cursor.fetchone()
    conn.close()
    return user[0] if user else None

def get_employee_details(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.first_name, u.last_name, u.email, u.phone,
               e.position, e.department, e.experience, e.address,
               e.job_info, e.skills, e.salary
        FROM User u
        JOIN Employee e ON u.user_id = e.user_id
        WHERE u.user_id = %s
    """, (user_id,))
    emp = cursor.fetchone()
    conn.close()
    return emp if emp else None

def refresh_employee_details():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Fetch User data
        cursor.execute("SELECT first_name, last_name, email, phone FROM User WHERE user_id=%s", (user_id,))
        user_data = cursor.fetchone()

        # Fetch Employee data
        cursor.execute("""SELECT address, skills FROM Employee WHERE user_id=%s""", (user_id,))
        employee_data = cursor.fetchone()

        conn.close()

        if user_data and employee_data:
            full_data = list(user_data) + list(employee_data)
            for i, value in enumerate(full_data):
                entries[i].delete(0, 'end')
                entries[i].insert(0, str(value))
        else:
            messagebox.showwarning("Not Found", "No data found for the given user ID.")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to refresh data:\n{str(e)}")


# === Save Function ===
def save_employee_details():
    new_values = [entry.get().strip() for entry in entries]
    
    if not all(new_values):
        messagebox.showerror("Error", "All fields must be filled out!")
        return

    # Assuming the first 4 entries are still for the User table
    if len(new_values) < 6:
        messagebox.showerror("Error", "Incomplete employee data!")
        return

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Update User table (first 4 fields)
        cursor.execute(
            "UPDATE User SET first_name=%s, last_name=%s, email=%s, phone=%s WHERE user_id=%s",
            (new_values[0], new_values[1], new_values[2], new_values[3], user_id)
        )

        # Update only 'address' and 'skills' in Employee table
        cursor.execute(
            "UPDATE Employee SET address=%s, skills=%s WHERE user_id=%s",
            (new_values[4], new_values[5], user_id)
        )

        conn.commit()
        messagebox.showinfo("Success", "Employee details updated successfully!")

        # Disable fields and reset button
        for entry in entries:
            entry.configure(state="disabled")

        edit_button.configure(text="✏️ Edit", fg_color="#28A745", text_color="white", command=make_fields_editable)

    except Exception as e:
        messagebox.showerror("Database Error", str(e))
    finally:
        conn.close()


# === Enable Editing ===
def make_fields_editable():
    for entry in entries:
        entry.configure(state="normal")
    edit_button.configure(text="💾 Save", fg_color="#007BFF", text_color="white", command=save_employee_details)

# === Go Back ===
def go_back():
    root.destroy()
    subprocess.Popen(["python", "employee_dashboard.py", user_email])



# === Fetch Data ===
user_id = get_user_id(user_email)
if not user_id:
    messagebox.showerror("Error", "User not found!")
    sys.exit(1)

employee = get_employee_details(user_id)
if not employee:
    messagebox.showerror("Error", "Employee not found!")
    sys.exit(1)

# === UI Setup ===
root = ctk.CTk()
root.title("Employee Personal Info")
root.geometry("480x620")
root.configure(fg_color="#92E3B4")
root.resizable(False, False)

# === Title and Back ===
tk.Label(root, text="Employee Dashboard", font=("Arial", 16, "bold"), bg="#92E3B4").place(x=20, y=40)
ctk.CTkButton(root, text="← Back", command=go_back, font=("Arial", 11),
              fg_color="white", text_color="black", width=80, hover_color="#DDDDDD", corner_radius=8).place(x=300, y=40)

ctk.CTkButton(root, text="Refresh", command=refresh_employee_details, font=("Arial", 11),
              fg_color="white", text_color="black", width=80, hover_color="#DDDDDD", corner_radius=8).place(x=390, y=40)

# --- Load Feature Icons ---
def load_icon(path):
    try:
        img = Image.open(path).resize((90, 90), Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except:
        return None

profile_icon1 = load_icon("images/profile_icon1.png")

if profile_icon1:
    icon_label = tk.Label(root, image=profile_icon1, bg="#92E3B4").place(x=50, y=100)  # Adjust position

tk.Label(root, text=f"{employee[0]} {employee[1]}", font=("Arial", 12, "bold"), bg="#92E3B4").place(x=60, y=200)

# === Field Labels and Entries (hardcoded positions) ===
entries = []

tk.Label(root, text="First Name:", font=("Arial", 12), bg="#92E3B4").place(x=20, y=280)
first_name = ctk.CTkEntry(root, width=300, height=30, corner_radius=10)
first_name.insert(0, employee[0])
first_name.configure(state="readonly")
first_name.place(x=90, y=220)
entries.append(first_name)

tk.Label(root, text="Last Name:", font=("Arial", 12), bg="#92E3B4").place(x=20, y=340)
last_name = ctk.CTkEntry(root, width=300, height=30, corner_radius=10)
last_name.insert(0, employee[1])
last_name.configure(state="readonly")
last_name.place(x=90, y=270)
entries.append(last_name)

tk.Label(root, text="Email:", font=("Arial", 12), bg="#92E3B4").place(x=20, y=400)
email = ctk.CTkEntry(root, width=300, height=30, corner_radius=10)
email.insert(0, employee[2])
email.configure(state="readonly")
email.place(x=90, y=320)
entries.append(email)

tk.Label(root, text="Phone:", font=("Arial", 12), bg="#92E3B4").place(x=20, y=470)
phone = ctk.CTkEntry(root, width=300, height=30, corner_radius=10)
phone.insert(0, employee[3])
phone.configure(state="readonly")
phone.place(x=90, y=370)
entries.append(phone)


tk.Label(root, text="Address:", font=("Arial", 12), bg="#92E3B4").place(x=20, y=530)
address = ctk.CTkEntry(root, width=300, height=30, corner_radius=10)
address.insert(0, employee[7])
address.configure(state="readonly")
address.place(x=90, y=420)
entries.append(address)


tk.Label(root, text="Skills:", font=("Arial", 12), bg="#92E3B4").place(x=20, y=590)
skills = ctk.CTkEntry(root, width=300, height=30, corner_radius=10)
skills.insert(0, employee[9])
skills.configure(state="readonly")
skills.place(x=90, y=470)
entries.append(skills)




# === Edit/Save Button ===
edit_button = ctk.CTkButton(root, text="✏ Edit", command=make_fields_editable,
                            font=("Arial", 11, "bold"), fg_color="white", text_color="black",
                            width=100, height=35, corner_radius=10)
edit_button.place(x=290, y=520)

# === Run ===
root.mainloop()
