import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
from database import get_db_connection
import sys
import customtkinter as ctk
from datetime import datetime

# === Get user email from command-line args ===
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# === Functions ===
def go_back():
    root.destroy()
    subprocess.Popen(["python", "employee_dashboard.py", user_email])

def clock_in():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO Time_Tracking (user_id, clock_in)
            VALUES ((SELECT user_id FROM User WHERE email=%s), NOW())
        """, (user_email,))
        conn.commit()
        conn.close()

        now = datetime.now().strftime("%I:%M %p")
        status_label.config(text=f"✅ Clocked in at {now}", fg="green")

    except Exception as e:
        status_label.config(text=f"❌ Clock-In failed: {str(e)}", fg="red")

def clock_out():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE Time_Tracking 
            SET clock_out = NOW() 
            WHERE user_id = (SELECT user_id FROM User WHERE email=%s) 
            AND clock_out IS NULL
        """, (user_email,))
        
        if cursor.rowcount == 0:
            status_label.config(text="⚠️ No active Clock-In found!", fg="orange")
        else:
            conn.commit()
            now = datetime.now().strftime("%I:%M %p")
            status_label.config(text=f"🕓 Clocked out at {now}", fg="blue")

        conn.close()
    except Exception as e:
        status_label.config(text=f"❌ Clock-Out failed: {str(e)}", fg="red")

# === UI Setup ===
root = tk.Tk()
root.title("Clock-In / Clock-Out")
root.geometry("500x400")
root.configure(bg="#D1F2C9")

# === Clock Image ===
try:
    clock_image = Image.open("images/clock_icon.png").resize((100, 100), Image.LANCZOS)
    clock_photo = ImageTk.PhotoImage(clock_image)
    image_label = tk.Label(root, image=clock_photo, bg="#D1F2C9")
    image_label.image = clock_photo
    image_label.place(x=200, y=20)
except Exception as e:
    print(f"Error loading image: {e}")

# === Title ===
tk.Label(root, text="Clock-In / Clock-Out", font=("Arial", 16, "bold"), bg="#D1F2C9").place(x=150, y=130)

# === Clock Buttons ===
ctk.CTkButton(root, text="Clock-In", command=clock_in, font=("Arial", 30, "bold"),
          fg_color="green", hover_color="darkgreen", width=30, corner_radius=12).place(x=80, y=180)

ctk.CTkButton(root, text="Clock-Out", command=clock_out, font=("Arial", 30, "bold"),
          fg_color="red", hover_color="darkred", width=30, corner_radius=12).place(x=260, y=180)

# === Status Label (message display) ===
status_label = tk.Label(root, text="", font=("Arial", 12, "bold"), bg="#D1F2C9")
status_label.place(x=140, y=240)

# === Back Button ===
ctk.CTkButton(root, text="Back", command=go_back, font=("Arial", 30, "bold"),
          fg_color="gray", hover_color="darkgray", width=20, corner_radius=12).place(x=190, y=300)

root.mainloop()
