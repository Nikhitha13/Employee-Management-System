import mysql.connector

def get_db_connection():
    return mysql.connector.connect(
        host="141.209.241.57",
        user="gali2n",
        password="mypass",
        database="BIS698W1700_GRP1",
        autocommit=True
    )

def setup_database():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create User table with validations and status
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS User (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL CHECK (email LIKE '%@gmail.com'),
            password VARCHAR(255) NOT NULL CHECK (CHAR_LENGTH(password) >= 8),
            phone VARCHAR(20) NOT NULL CHECK (CHAR_LENGTH(phone) BETWEEN 10 AND 20),
            role ENUM('employee', 'admin') DEFAULT 'employee',
            status ENUM('active', 'inactive') DEFAULT 'active'
        )
    """)

    # Employee table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Employee (
            user_id INT PRIMARY KEY,
            position VARCHAR(255) NOT NULL,
            department VARCHAR(255) NOT NULL,
            experience INT NOT NULL CHECK (experience >= 0),
            address TEXT,
            job_info TEXT,
            skills TEXT,
            salary DECIMAL(10,2) NOT NULL CHECK (salary >= 0),
            FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
        )
    """)

    # Admin table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Admin (
            user_id INT PRIMARY KEY,
            FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
        )
    """)

    # Time tracking
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Time_Tracking (
            tracking_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            clock_in TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            clock_out TIMESTAMP NULL,
            total_hours DECIMAL(5,2) GENERATED ALWAYS AS 
                (TIMESTAMPDIFF(SECOND, clock_in, clock_out) / 3600) STORED,
            FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE
        )
    """)

    # Default Admin
    cursor.execute("SELECT COUNT(*) FROM User WHERE email = 'admin@gmail.com'")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
            INSERT INTO User (first_name, last_name, email, password, phone, role, status)
            VALUES ('Admin', 'One', 'admin@gmail.com', 'admin1234', '+15551112222', 'admin', 'active')
        """)
        admin_id = cursor.lastrowid
        cursor.execute("INSERT INTO Admin (user_id) VALUES (%s)", (admin_id,))

    # Default Employee
    cursor.execute("SELECT COUNT(*) FROM User WHERE email = 'navya@gmail.com'")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
            INSERT INTO User (first_name, last_name, email, password, phone, role, status)
            VALUES ('navya', 'gali', 'navya@gmail.com', 'navya123456', '+15553334444', 'employee', 'active')
        """)
        employee_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO Employee (user_id, position, department, experience, address, job_info, skills, salary)
            VALUES (%s, 'Software Engineer', 'IT', 2, '123 Main St', 'Handles backend and frontend tasks.', 'Python, SQL, APIs', 55000.00)
        """, (employee_id,))

    conn.commit()
    conn.close()
    print("✅ Database setup completed successfully with 'status' field added!")

if __name__ == "__main__":
    setup_database()
