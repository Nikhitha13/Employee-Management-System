import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox
from database import get_db_connection
import subprocess
import sys

# ✅ Get Email Argument
if len(sys.argv) > 1:
    user_email = sys.argv[1]
else:
    messagebox.showerror("Error", "User email not provided!")
    sys.exit(1)

# ✅ Fetch Employees from DB
def fetch_employees(search_text="", status_filter="All"):
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        SELECT u.first_name, u.last_name, u.email, u.phone, u.role, u.status,
               e.position, e.department, e.experience, e.salary
        FROM User u
        JOIN Employee e ON u.user_id = e.user_id
        WHERE u.role = 'employee'
    """

    params = []

    if status_filter != "All":
        query += " AND u.status = %s"
        params.append(status_filter.lower())

    if search_text:
        query += " AND (u.first_name LIKE %s OR u.last_name LIKE %s OR u.email LIKE %s)"
        search_param = f"%{search_text}%"
        params.extend([search_param, search_param, search_param])

    cursor.execute(query, tuple(params))
    rows = cursor.fetchall()
    conn.close()
    return rows

# ✅ UI Setup
root = ctk.CTk()
root.title("View All Employees")
root.geometry("840x600")
root.configure(fg_color="#E8F5E9")

# === Title Frame with Back Button ===
title_frame = ctk.CTkFrame(root, fg_color="#E8F5E9")
title_frame.pack(fill="x", padx=20, pady=10)

ctk.CTkLabel(title_frame, text="All Employees", font=("Arial", 24, "bold"), text_color="black").pack(side="left", padx=10)

def go_back():
    root.destroy()
    subprocess.Popen(["python", "admin_dashboard.py", user_email])

ctk.CTkButton(title_frame, text="← Back", command=go_back, width=100,
              fg_color="#F44336", text_color="white").pack(side="right", padx=10)

# === Search & Filter Frame ===
top_frame = ctk.CTkFrame(root, fg_color="#C8E6C9")
top_frame.pack(pady=10, padx=20, fill="x")

search_entry = ctk.CTkEntry(top_frame, placeholder_text="Search by name or email", width=500)
search_entry.pack(side="left", padx=10, pady=10)

status_menu = ctk.CTkOptionMenu(top_frame, values=["All", "Active", "Inactive"], width=150)
status_menu.set("All")
status_menu.pack(side="left", padx=10)

def refresh_list():
    for widget in list_frame.winfo_children():
        widget.destroy()

    search_term = search_entry.get().strip()
    status_value = status_menu.get()
    employees = fetch_employees(search_term, status_value)

    if not employees:
        ctk.CTkLabel(list_frame, text="No matching employees found.",
                     font=("Arial", 14), text_color="gray").grid(row=0, column=0, padx=10, pady=20)
        return

    headers = ["Name", "Email", "Phone", "Status", "Position", "Department", "Experience", "Salary"]
    for col, header in enumerate(headers):
        ctk.CTkLabel(list_frame, text=header, font=("Arial", 13, "bold"), text_color="#333").grid(row=0, column=col, padx=10, pady=5, sticky="w")

    for row_num, emp in enumerate(employees, start=1):
        name = f"{emp[0]} {emp[1]}"
        email = emp[2]
        phone = emp[3]
        status = emp[5].capitalize()
        position = emp[6]
        department = emp[7]
        experience = f"{emp[8]} yrs"
        salary = f"${emp[9]:,.2f}"

        row_data = [name, email, phone, status, position, department, experience, salary]

        for col, data in enumerate(row_data):
            ctk.CTkLabel(list_frame, text=data, font=("Arial", 12), text_color="#000").grid(row=row_num, column=col, padx=10, pady=4, sticky="w")

ctk.CTkButton(top_frame, text="🔍 Search", command=refresh_list, width=120,
              fg_color="#4CAF50", text_color="white").pack(side="left", padx=10)

# === Scrollable Table Frame ===
scroll_canvas = tk.Canvas(root, bg="#E8F5E9", highlightthickness=0, height=400)
scroll_frame = tk.Frame(scroll_canvas, bg="#E8F5E9")
scrollbar = tk.Scrollbar(root, orient="vertical", command=scroll_canvas.yview)
scroll_canvas.configure(yscrollcommand=scrollbar.set)

scrollbar.pack(side="right", fill="y")
scroll_canvas.pack(side="left", fill="both", expand=True)
scroll_canvas.create_window((0, 0), window=scroll_frame, anchor="nw")

def on_configure(event):
    scroll_canvas.configure(scrollregion=scroll_canvas.bbox("all"))

scroll_frame.bind("<Configure>", on_configure)

# === List Container ===
list_frame = ctk.CTkFrame(scroll_frame, fg_color="#FFFFFF")
list_frame.pack(fill="both", expand=True, padx=20, pady=20)

# === Initial Load ===
refresh_list()

# === Run App ===
root.mainloop()
